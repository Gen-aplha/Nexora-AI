/* NEXORA AI website settings.
   After you upload your APK to a public HTTPS file page, paste the direct APK URL below.
   Example format only: https://your-domain.example/NEXORA-AI.apk
*/
window.NEXORA_CONFIG = {
  apkUrl: "",
  appVersion: "Coming soon"
};
